﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Square
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //загрузка текста из файла
        private void buttonOpenFile_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.Cancel)return;
            //получаем выбранный файл
            string filename = openFileDialog1.FileName;
            //читаем файл в строку
            richTextBoxEncryption.Text = System.IO.File.ReadAllText(filename);
        }
        //старт шифрования
        private void buttonEncryption_Click(object sender, EventArgs e)
        {
            if (richTextBoxEncryption.Text.Length > 0)
            {
                if (textBoxKey.Text.Length == 16)
                {
                    Thread th = new Thread(Encryption);
                    th.Start();
                }  
                else MessageBox.Show("Нет ключа для шифрования, который должен состоять из 16 символов.", "Сообщение");
            }
            else
            {
                MessageBox.Show("Нет текста для шифрования.", "Сообщение");
            }
        }
        private void Encryption()
        {
            Square SquareCl = new Square();
            this.Invoke(new MethodInvoker(delegate
            {
                //шифрование
                byte[] mas_result=SquareCl.Encryption(richTextBoxEncryption.Text, textBoxKey.Text);
                File.WriteAllBytes("Encryption.txt", mas_result);
                mas_result = File.ReadAllBytes("Encryption.txt");
                //расшифрование
                mas_result = SquareCl.Decryption(mas_result, textBoxKey.Text);
                File.WriteAllBytes("Decryption.txt", mas_result);
            }));
        }
        private void textBoxKey_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 'A' && e.KeyChar <= 'Z') || (e.KeyChar >= 'a' && e.KeyChar <= 'z') || (e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == '_' || e.KeyChar == (char)Keys.Back)
            {

            }
            else
            {
                e.Handled = true;
            }
        }
    }
}
